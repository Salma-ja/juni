# Prompt: implement and integrate JUNI backend

You are a senior backend engineer and Supabase/PostgreSQL architect. Work directly from the full JUNI repository, inspect every existing source file, UI screen, Supabase migration, auth setup, docs, data types, and mock data. Do not assume the README alone represents the implementation.

Repository: https://github.com/Salma-ja/juni

JUNI is a student ride-sharing Expo/React Native TypeScript app. Implement a complete, maintainable backend and integrate it into the existing app without changing the UI design or breaking existing navigation.

## First: repository audit
- Map current screens, state, data flows, mock services, types, auth, and Supabase config.
- Identify all mock/sample/static data and trace which screen consumes it.
- Read project docs, particularly matching/fare, booking/cancellation, captain and safety specifications.
- Preserve current Supabase auth provider/configuration and migration history.
- Write an integration plan and list schema conflicts before modifying anything.

## Architecture requirements
Use Supabase (Auth, PostgreSQL, RLS, REST/PostgREST, SQL RPC, Edge Functions where secrets/webhooks or privileged operations are needed). Do not add a separate backend framework unless the repository constraints justify it. Keep service-role secrets server-side only.

Implement:
1. Authentication: phone OTP and approved university email verification consistent with existing screens. Secure session refresh, logout, and verified-account gating.
2. Profiles: student profiles, university, verification state, roles, safe profile editing.
3. University configuration and approved email-domain validation.
4. Captain onboarding: approval, license verification state, vehicle records/capacity and availability.
5. Ride requests: campus, class time, pickup/dropoff labels and coordinates, passenger count, preferences, status.
6. Matching: time windows, pickup/destination compatibility, route feasibility, seat inventory, preference rules, fare cap; use real road distance where supported, not straight-line distance as final production fare. Clearly label estimates.
7. Ride groups: create/list/detail, capacity, route/stops, scheduled pickup, campus ETA, group status.
8. Booking lifecycle: hold with expiry, atomic seat reservation, payment simulation for prototype, idempotent confirmation, prevent duplicate booking and overbooking.
9. Captain assignment and confirmation: eligibility, licensed vehicle capacity, no overlapping commitments, captain cancel/reassignment behavior.
10. Payment abstraction: simulation provider now, clean interface for future payment provider, server-only provider webhooks, idempotency. Never claim live payments are integrated.
11. Cancellation/refunds: enforce documented 12-hour cutoff measured from scheduled pickup (exactly 12h gets full refund), no ordinary cancellation after trip starts; preserve other passengers' fares and seats.
12. Trip lifecycle: awaiting captain, confirmed, in progress, completed/cancelled, trip events.
13. Safety: trip sharing and SOS event workflow with clear limitations; never imply emergency responders are automatically contacted unless integration exists.
14. Favorites/saved pickup places and ride history as supported by UI.
15. Notifications: provider abstraction for push notifications and event-triggered notifications, but do not include real credentials.
16. Admin workflows: approve students/captains, universities/domains, vehicles, manage exceptions; admin access protected by secure role claims/authorization.
17. API contract and documentation: all endpoints, RPCs, request/response shapes, error codes, auth rules.
18. Database: normalized schema, constraints, indexes, migration files, seed data safe for development only.
19. Security: RLS on every exposed table, least privilege, validation, rate limiting, secure secrets, no trusting client-sent role/verification/fare/payment status.
20. Tests: SQL/API tests for permissions, OTP gate, matching, seat race conditions, idempotency, holds expiry, payment failure, cancellation boundary, trip start and captain eligibility.

## Implementation rules
- Build the backend in the repository's existing structure; avoid duplicate schema/migrations.
- Integrate actual frontend screens to real data in manageable vertical slices. Remove mocks only when the real feature works.
- Create reusable typed API/service layer and state/loading/error/empty states.
- Do not silently change business rules. Where specs conflict, report the conflict and choose the documented rule only after explaining.
- No secrets, personal data, or production credentials in commits.
- Use migrations, not manual undocumented schema changes.
- Run typecheck, lint, tests and build. Fix all introduced failures.
- Add setup instructions and a `.env.example`.
- Deliver a summary of files changed, architecture diagram, API documentation, migration/setup commands, tests run and any unfinished/blocked items.

Do not merely generate a plan or pseudocode: implement the backend and integration code, test it, and leave the repository in a runnable state. If an external provider credential is unavailable, implement a safe mock/provider interface and document the required secret/configuration.
