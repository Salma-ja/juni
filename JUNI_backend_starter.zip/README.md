# JUNI Backend Starter (Supabase)

Backend foundation tailored to the JUNI Expo/React Native student ride-sharing app.

## Contents
- `supabase/migrations/`: core PostgreSQL schema, RLS policies, booking/payment/cancellation/captain RPCs.
- `docs/API.md`: API/RPC reference and integration outline.
- `.env.example`: frontend Supabase environment variables (no secrets).
- `docs/IMPLEMENTATION_NOTES.md`: limitations and next steps.

## Prerequisites
- Supabase project
- Supabase CLI
- Node/npm for the existing Expo app

## Apply migration
Review the existing `supabase/` directory in the app repository first to avoid duplicate tables or conflicting migrations. Then copy this migration into the repo's `supabase/migrations/`.

With Supabase CLI linked to your project:
```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```
Or paste the migration into Supabase SQL Editor for a fresh backend (recommended to apply in a staging project first).

## Configure app
Set the variables in `.env` (never commit credentials):
```env
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
```
The mobile app uses the anon/publishable key. Never put the service-role key in the app.

## Important
This is a backend foundation, not a production-ready launch. It must be reviewed and tested against the current app schema, existing auth setup, and UI flows. Payment is simulation only. SOS is an event record, not a staffed emergency service. Captain approvals/admin functions need a secure admin workflow. See implementation notes.
