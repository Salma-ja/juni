# JUNI API / Supabase Contract

Supabase provides authenticated REST access to tables and RPC endpoints. Use the authenticated user's JWT from Supabase Auth; never expose service-role credentials in the client.

## Auth
Use Supabase Auth OTP for configured phone and university email verification. Follow the repository's existing auth setup and do not create a parallel auth provider. App client uses session/JWT.

## Table REST APIs (PostgREST)
Base URL: `${SUPABASE_URL}/rest/v1`

| Resource | Common operations | Access |
|---|---|---|
| `universities` | list active universities | authenticated |
| `profiles` | get/update own profile | self only |
| `ride_requests` | create/read/update own ride requests | owner |
| `ride_groups` | discover groups, inspect ride details | authenticated, filtered by RLS |
| `bookings` | read own bookings | rider / assigned captain |
| `payments` | read own payment records | booking owner |
| `trip_events` | read group events; insert participant events | group participant |
| `saved_places` | CRUD saved pickup/favorite places | owner |

## RPC endpoints
POST `/rest/v1/rpc/create_booking`
```json
{"p_group_id":"uuid","p_seats":1,"p_fare":5.0,"p_request_id":null}
```
Creates a five-minute seat hold. Capacity is checked while locking the group row.

POST `/rest/v1/rpc/confirm_simulated_payment`
```json
{"p_booking_id":"uuid","p_success":true,"p_idempotency_key":"unique-client-generated-key"}
```
Converts the hold to awaiting-captain booking and records a simulated payment outcome.

POST `/rest/v1/rpc/cancel_booking`
```json
{"p_booking_id":"uuid"}
```
Applies the 12-hour pickup cancellation boundary; refunds are simulation records only.

POST `/rest/v1/rpc/confirm_group_as_captain`
```json
{"p_group_id":"uuid","p_vehicle_id":"uuid"}
```
Requires an approved, license-verified captain and their active vehicle.

## Suggested app flow
1. Auth OTP → verify university account and create profile.
2. Create ride request → search matching open groups.
3. Show matching groups, pickup/arrival estimates, capacity, preferences, and fare.
4. Create booking hold → payment simulation success/failure.
5. Show awaiting captain → captain confirmation → trip status events.
6. Cancel booking → show refund eligibility based on scheduled pickup.

## Error identifiers
RPC exceptions include `AUTH_REQUIRED`, `GROUP_NOT_FOUND`, `GROUP_NOT_BOOKABLE`, `SEATS_UNAVAILABLE`, `ALREADY_BOOKED`, `FARE_CAP_EXCEEDED`, `HOLD_EXPIRED`, `CAPTAIN_NOT_ELIGIBLE`, `VEHICLE_INVALID`, and `TRIP_ALREADY_STARTED`.
