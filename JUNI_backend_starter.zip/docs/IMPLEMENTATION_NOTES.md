# Implementation notes / production checklist

## Important review items before merge
- This migration is additive but may conflict with existing schema in the repo's Supabase directory. Inspect current migration files and Auth setup before applying.
- RLS is a starter policy set. Review the profile update policy: role, verification and university fields must be protected from client tampering (implement a secure update RPC/trigger).
- The `create_booking` and `confirm_simulated_payment` SQL functions should receive a PostgreSQL test pass. The seat-count query should be reviewed for operator precedence and converted to explicit parenthesized filters before production.
- Create admin-only workflows for university-domain allowlists, user verification, captain approval, license verification and vehicle review. Never expose admin/service role to mobile clients.
- Add geospatial matching (PostGIS) and road-distance routing provider. Current schema stores coordinates but matching logic is not implemented as a server function.
- Implement automatic hold expiry cleanup (scheduled job) and retry-safe payment provider webhook handling.
- Add rate limits, abuse reporting, moderation, logging, and retention policy for sensitive trip/location events.
- SOS/event recording alone does not call emergency services. A real pilot needs an operational safety plan and escalation/contact handling.
- Payment provider is simulated; production payment processing must be server-side and provider-webhook verified.
- Add tests for race conditions, RLS, auth, 12-hour boundary (including exactly 12h), cancellation after trip start, duplicate callbacks/idempotency, and capacity.
- Confirm fare calculation, captain scheduling/repositioning, vehicle licensed capacity, group max, and gender preference rules against the project's detailed specification and current frontend.
- Build API integration layer in the frontend and replace mock data screen by screen; don't rewrite frontend screens without validating contracts.

## Backend architecture
Supabase Auth → JWT → PostgREST/RPC → PostgreSQL + RLS.
Transactional state changes are SQL functions to avoid client-side race conditions. Supabase Edge Functions can be added for provider webhooks, notifications, route provider secrets and admin operations.
