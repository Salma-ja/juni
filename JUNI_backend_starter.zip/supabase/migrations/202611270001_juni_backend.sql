-- JUNI backend foundation for Supabase
-- Apply via Supabase CLI or SQL editor. Review existing schema before applying.
create extension if not exists pgcrypto;

create type public.user_role as enum ('student','captain','admin');
create type public.ride_request_status as enum ('searching','matched','cancelled','completed');
create type public.ride_group_status as enum ('open','full','captain_pending','confirmed','in_progress','completed','cancelled');
create type public.booking_status as enum ('hold','booked','awaiting_captain','confirmed','cancelled','completed');
create type public.payment_status as enum ('pending','succeeded','failed','refunded','refund_not_eligible');
create type public.trip_event_type as enum ('status_change','pickup_arrived','boarding','trip_started','trip_completed','sos','shared_location','note');

create table if not exists public.universities (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  city text not null default 'Irbid',
  campus_name text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  university_id uuid references public.universities(id),
  university_email text,
  role public.user_role not null default 'student',
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected')),
  gender text check (gender is null or gender in ('female','male','other','prefer_not_to_say')),
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists profiles_phone_unique on public.profiles(phone) where phone is not null;
create unique index if not exists profiles_uni_email_unique on public.profiles(lower(university_email)) where university_email is not null;

create table if not exists public.captain_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  license_verified boolean not null default false,
  approval_status text not null default 'pending' check (approval_status in ('pending','approved','rejected','suspended')),
  rating numeric(3,2) check (rating is null or rating between 0 and 5),
  availability boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  captain_id uuid not null references public.captain_profiles(user_id) on delete cascade,
  make text,
  model text,
  color text,
  plate_number text,
  seat_capacity integer not null check (seat_capacity between 1 and 8),
  category text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.ride_requests (
  id uuid primary key default gen_random_uuid(),
  rider_id uuid not null references public.profiles(id) on delete cascade,
  university_id uuid not null references public.universities(id),
  pickup_label text not null,
  pickup_lat double precision,
  pickup_lng double precision,
  destination_label text not null,
  destination_lat double precision,
  destination_lng double precision,
  class_start_at timestamptz not null,
  requested_departure_at timestamptz,
  preferred_gender text check (preferred_gender is null or preferred_gender in ('female','male','any')),
  seats_requested integer not null default 1 check (seats_requested between 1 and 4),
  fare_cap numeric(8,2),
  status public.ride_request_status not null default 'searching',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ride_requests_search_idx on public.ride_requests(university_id,class_start_at,status);

create table if not exists public.ride_groups (
  id uuid primary key default gen_random_uuid(),
  university_id uuid not null references public.universities(id),
  pickup_label text not null,
  pickup_lat double precision,
  pickup_lng double precision,
  destination_label text not null,
  destination_lat double precision,
  destination_lng double precision,
  scheduled_pickup_at timestamptz not null,
  campus_arrival_at timestamptz,
  max_seats integer not null default 4 check (max_seats between 1 and 8),
  captain_id uuid references public.captain_profiles(user_id),
  vehicle_id uuid references public.vehicles(id),
  status public.ride_group_status not null default 'open',
  route_distance_km numeric(8,2),
  base_fare numeric(8,2) not null default 0 check (base_fare >= 0),
  fare_per_km numeric(8,2) not null default 0 check (fare_per_km >= 0),
  fare_cap numeric(8,2),
  captain_confirmed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ride_groups_discovery_idx on public.ride_groups(university_id,scheduled_pickup_at,status);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.ride_groups(id),
  rider_id uuid not null references public.profiles(id) on delete cascade,
  request_id uuid references public.ride_requests(id),
  seats integer not null default 1 check (seats between 1 and 4),
  status public.booking_status not null default 'hold',
  hold_expires_at timestamptz,
  fare_amount numeric(8,2) not null check (fare_amount >= 0),
  refund_policy_hours integer not null default 12,
  cancellation_requested_at timestamptz,
  refund_amount numeric(8,2) not null default 0,
  cancelled_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(group_id,rider_id)
);
create index if not exists bookings_rider_idx on public.bookings(rider_id,status);
create index if not exists bookings_group_idx on public.bookings(group_id,status);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id),
  amount numeric(8,2) not null check (amount >= 0),
  currency text not null default 'JOD',
  status public.payment_status not null default 'pending',
  provider text not null default 'simulation',
  provider_reference text,
  idempotency_key text unique,
  paid_at timestamptz,
  refunded_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.trip_events (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.ride_groups(id) on delete cascade,
  booking_id uuid references public.bookings(id) on delete set null,
  actor_id uuid references public.profiles(id),
  event_type public.trip_event_type not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists trip_events_group_time_idx on public.trip_events(group_id,created_at);

create table if not exists public.saved_places (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  label text not null,
  address text not null,
  lat double precision,
  lng double precision,
  created_at timestamptz not null default now()
);

-- Profiles are self-readable/self-editable. Role and verification fields cannot be safely
-- changed by clients; production should use a restricted profile-update RPC or trigger.
alter table public.universities enable row level security;
alter table public.profiles enable row level security;
alter table public.captain_profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.ride_requests enable row level security;
alter table public.ride_groups enable row level security;
alter table public.bookings enable row level security;
alter table public.payments enable row level security;
alter table public.trip_events enable row level security;
alter table public.saved_places enable row level security;

create policy "active universities visible" on public.universities for select using (is_active=true);
create policy "profile owner select" on public.profiles for select using (auth.uid()=id);
create policy "profile owner insert" on public.profiles for insert with check (auth.uid()=id);
create policy "profile owner update" on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);
create policy "captain self or approved visible" on public.captain_profiles for select using (auth.uid()=user_id or approval_status='approved');
create policy "captain owner insert" on public.captain_profiles for insert with check (auth.uid()=user_id);
create policy "captain owner update" on public.captain_profiles for update using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "active vehicles visible" on public.vehicles for select using (is_active=true);
create policy "captain manage own vehicles" on public.vehicles for all using (auth.uid()=captain_id) with check (auth.uid()=captain_id);
create policy "rider manages own requests" on public.ride_requests for all using (auth.uid()=rider_id) with check (auth.uid()=rider_id);
create policy "ride groups discoverable by authenticated users" on public.ride_groups for select to authenticated using (status in ('open','full','captain_pending','confirmed','in_progress') or auth.uid()=captain_id);
create policy "captain updates assigned groups" on public.ride_groups for update using (auth.uid()=captain_id) with check (auth.uid()=captain_id);
create policy "riders see own bookings and captains see assigned group bookings" on public.bookings for select using (auth.uid()=rider_id or exists(select 1 from public.ride_groups g where g.id=group_id and g.captain_id=auth.uid()));
create policy "riders insert own booking" on public.bookings for insert with check (auth.uid()=rider_id);
create policy "riders update own booking" on public.bookings for update using (auth.uid()=rider_id) with check (auth.uid()=rider_id);
create policy "payment owner read" on public.payments for select using (exists(select 1 from public.bookings b where b.id=booking_id and b.rider_id=auth.uid()));
create policy "trip events visible to group participants" on public.trip_events for select using (
  exists(select 1 from public.bookings b where b.group_id=trip_events.group_id and b.rider_id=auth.uid() and b.status not in ('cancelled'))
  or exists(select 1 from public.ride_groups g where g.id=trip_events.group_id and g.captain_id=auth.uid())
);
create policy "participants may add trip events" on public.trip_events for insert with check (
  auth.uid()=actor_id and (exists(select 1 from public.bookings b where b.group_id=trip_events.group_id and b.rider_id=auth.uid()) or exists(select 1 from public.ride_groups g where g.id=trip_events.group_id and g.captain_id=auth.uid()))
);
create policy "saved places owner only" on public.saved_places for all using (auth.uid()=user_id) with check (auth.uid()=user_id);

-- Atomically reserve seats. A row lock on the group serializes competing reservations.
create or replace function public.create_booking(p_group_id uuid,p_seats integer default 1,p_fare numeric default null,p_request_id uuid default null)
returns public.bookings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid := auth.uid();
  v_group public.ride_groups;
  v_used integer;
  v_fare numeric(8,2);
  v_booking public.bookings;
begin
  if v_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  if p_seats < 1 or p_seats > 4 then raise exception 'INVALID_SEAT_COUNT'; end if;
  select * into v_group from public.ride_groups where id=p_group_id for update;
  if not found then raise exception 'GROUP_NOT_FOUND'; end if;
  if v_group.status not in ('open','full') then raise exception 'GROUP_NOT_BOOKABLE'; end if;
  select coalesce(sum(seats),0) into v_used from public.bookings
    where group_id=p_group_id and status in ('booked','awaiting_captain','confirmed')
      or (group_id=p_group_id and status='hold' and hold_expires_at>now());
  if v_used+p_seats>v_group.max_seats then raise exception 'SEATS_UNAVAILABLE'; end if;
  if exists(select 1 from public.bookings where group_id=p_group_id and rider_id=v_uid and status not in ('cancelled')) then
    raise exception 'ALREADY_BOOKED';
  end if;
  v_fare := coalesce(p_fare,v_group.base_fare);
  if v_fare<0 or (v_group.fare_cap is not null and v_fare>v_group.fare_cap) then raise exception 'FARE_CAP_EXCEEDED'; end if;
  insert into public.bookings(group_id,rider_id,request_id,seats,status,hold_expires_at,fare_amount)
    values(p_group_id,v_uid,p_request_id,p_seats,'hold',now()+interval '5 minutes',v_fare)
    returning * into v_booking;
  return v_booking;
end;
$$;

-- Confirm simulated payment. Idempotency is enforced by booking-level unique payment.
create or replace function public.confirm_simulated_payment(p_booking_id uuid,p_success boolean,p_idempotency_key text)
returns public.payments
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid := auth.uid();
  v_booking public.bookings;
  v_payment public.payments;
  v_group public.ride_groups;
  v_used integer;
begin
  if v_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_booking from public.bookings where id=p_booking_id for update;
  if not found or v_booking.rider_id<>v_uid then raise exception 'BOOKING_NOT_FOUND'; end if;
  select * into v_payment from public.payments where booking_id=p_booking_id;
  if found then return v_payment; end if;
  if v_booking.status<>'hold' or v_booking.hold_expires_at<now() then raise exception 'HOLD_EXPIRED'; end if;
  if not p_success then
    update public.bookings set status='cancelled',updated_at=now() where id=p_booking_id;
    insert into public.payments(booking_id,amount,status,idempotency_key) values(p_booking_id,v_booking.fare_amount,'failed',p_idempotency_key) returning * into v_payment;
    return v_payment;
  end if;
  select * into v_group from public.ride_groups where id=v_booking.group_id for update;
  select coalesce(sum(seats),0) into v_used from public.bookings
    where group_id=v_booking.group_id and id<>p_booking_id and (status in ('booked','awaiting_captain','confirmed')
      or (status='hold' and hold_expires_at>now()));
  if v_used+v_booking.seats>v_group.max_seats then raise exception 'SEATS_UNAVAILABLE'; end if;
  update public.bookings set status='awaiting_captain',hold_expires_at=null,updated_at=now() where id=p_booking_id;
  insert into public.payments(booking_id,amount,status,idempotency_key,paid_at)
    values(p_booking_id,v_booking.fare_amount,'succeeded',p_idempotency_key,now()) returning * into v_payment;
  update public.ride_groups set status=case when v_used+v_booking.seats>=max_seats then 'captain_pending'::public.ride_group_status else 'open'::public.ride_group_status end,updated_at=now()
    where id=v_booking.group_id;
  return v_payment;
end;
$$;

-- Cancel booking; refund is simulated and policy is evaluated against scheduled pickup.
create or replace function public.cancel_booking(p_booking_id uuid)
returns public.bookings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid := auth.uid();
  v_booking public.bookings;
  v_group public.ride_groups;
  v_refund numeric(8,2) := 0;
  v_payment public.payments;
begin
  select * into v_booking from public.bookings where id=p_booking_id for update;
  if not found or v_booking.rider_id<>v_uid then raise exception 'BOOKING_NOT_FOUND'; end if;
  select * into v_group from public.ride_groups where id=v_booking.group_id for update;
  if v_group.status='in_progress' then raise exception 'TRIP_ALREADY_STARTED'; end if;
  if v_booking.status='cancelled' then return v_booking; end if;
  if v_booking.status='hold' then
    update public.bookings set status='cancelled',cancelled_by=v_uid,cancellation_requested_at=now(),updated_at=now() where id=p_booking_id returning * into v_booking;
    return v_booking;
  end if;
  if v_group.scheduled_pickup_at-now()>=interval '12 hours' then v_refund:=v_booking.fare_amount; end if;
  update public.bookings set status='cancelled',cancelled_by=v_uid,cancellation_requested_at=now(),refund_amount=v_refund,updated_at=now() where id=p_booking_id returning * into v_booking;
  update public.payments set status=case when v_refund>0 then 'refunded'::public.payment_status else 'refund_not_eligible'::public.payment_status end,refunded_at=case when v_refund>0 then now() else null end where booking_id=p_booking_id;
  insert into public.trip_events(group_id,booking_id,actor_id,event_type,details) values(v_booking.group_id,p_booking_id,v_uid,'status_change',jsonb_build_object('booking_status','cancelled','refund_amount',v_refund));
  return v_booking;
end;
$$;

-- Captain confirmation: only approved, licensed captains with a vehicle may confirm.
create or replace function public.confirm_group_as_captain(p_group_id uuid,p_vehicle_id uuid)
returns public.ride_groups
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid:=auth.uid();
  v_group public.ride_groups;
begin
  if not exists(select 1 from public.captain_profiles cp where cp.user_id=v_uid and cp.approval_status='approved' and cp.license_verified) then raise exception 'CAPTAIN_NOT_ELIGIBLE'; end if;
  if not exists(select 1 from public.vehicles v where v.id=p_vehicle_id and v.captain_id=v_uid and v.is_active) then raise exception 'VEHICLE_INVALID'; end if;
  select * into v_group from public.ride_groups where id=p_group_id for update;
  if not found or v_group.status not in ('captain_pending','full','open') then raise exception 'GROUP_NOT_CONFIRMABLE'; end if;
  update public.ride_groups set captain_id=v_uid,vehicle_id=p_vehicle_id,status='confirmed',captain_confirmed_at=now(),updated_at=now() where id=p_group_id returning * into v_group;
  update public.bookings set status='confirmed',updated_at=now() where group_id=p_group_id and status='awaiting_captain';
  return v_group;
end;
$$;

revoke all on function public.create_booking(uuid,integer,numeric,uuid) from public;
revoke all on function public.confirm_simulated_payment(uuid,boolean,text) from public;
revoke all on function public.cancel_booking(uuid) from public;
revoke all on function public.confirm_group_as_captain(uuid,uuid) from public;
grant execute on function public.create_booking(uuid,integer,numeric,uuid) to authenticated;
grant execute on function public.confirm_simulated_payment(uuid,boolean,text) to authenticated;
grant execute on function public.cancel_booking(uuid) to authenticated;
grant execute on function public.confirm_group_as_captain(uuid,uuid) to authenticated;

-- Keep profile timestamps current.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at=now(); return new; end; $$;
do $$
declare t text;
begin
  foreach t in array array['profiles','ride_requests','ride_groups','bookings'] loop
    execute format('drop trigger if exists set_updated_at_%I on public.%I',t,t);
    execute format('create trigger set_updated_at_%I before update on public.%I for each row execute function public.set_updated_at()',t,t);
  end loop;
end $$;
